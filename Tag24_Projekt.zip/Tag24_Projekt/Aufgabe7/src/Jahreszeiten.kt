fun main() {
    val monate: List<String> = listOf(
        "Januar", "Februar", "März", "April", "Mai", "Juni",
        "Juli", "August", "September", "Oktober", "November", "Dezember"
    )
    for (monate in monate)
        val jahresZeiten = jahresZeiten(monate){

    }
}










// Dezember, Januar, Februar -> Winter
// März, April, Mai -> Frühling
// Juni, Juli, August -> Sommer
// September, Oktober, November -> Herbst